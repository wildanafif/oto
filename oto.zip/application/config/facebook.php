<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config('appId')='965767220143286';
$config('secret')='2c5a67bbf53a57fc677c9382f615e90f';

?>