


	<div class="container">
		<div class="four">
      <div class="alert alert-success" role="alert">
        
  				<h2>Selamat !!!</h2>
  			 <p>Akun anda berhasil di aktifkan</p>
				<p>Silahkan Login untuk masuk</p>
      </div>
				  <a href="<?php echo site_url() ?>auth/masuk" class="more go">Login</a>
					
				
			</div>
</div>
</div>